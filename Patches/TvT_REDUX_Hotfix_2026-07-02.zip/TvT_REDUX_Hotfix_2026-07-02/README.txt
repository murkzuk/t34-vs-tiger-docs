==================================================
TvT_REDUX Hotfix 2026-07-02
==================================================

**Description:**
This is a small hotfix on top of TvT_REDUX Patch 0.001 - 14 script files only,
covering a mission AI bug, a broken hit effect, tank machine gun ballistics,
and a script error that spammed the log every time you switched cockpit views.
It does not include any executables, videos, or dgVoodoo files - if you're
already running Patch 0.001, you only need this.

**What's fixed:**

* Campaign 2, Mission 5 - three AI unit groups (SU-85 ambush, StuG 40s,
  Soviet riflemen) were either not loading at all or sitting completely
  inert with no AI behaviour. They now fight properly.

* Metal-hit splash/smoke effect - track and armour hits were showing
  oversized flames followed by solid cubes instead of smoke, caused by a
  particle count overrunning a texture's frame limit. Fixed, and a real
  metal fragment/debris effect has been added on impact (the game never
  had one before).

* Every tank machine gun previously shared one generic bullet velocity
  regardless of nationality. The German MG34 (Tiger, Pz IV, Hanomag) and
  Soviet DT-29 (T-34/76, T-34/85) now have their own real velocities.

* Fixed a script error ("Invalid this reference" in Cockpit.script) that
  spammed the execution log every time the view mode changed - caused by
  AI-driven tanks running player-only cockpit code without a guard the
  game already uses elsewhere. Purely a log/performance fix, not
  something you'd have noticed visually.

**Installation Steps:**

1. Backup: Always back up your Missions\ and Scripts\ folders before
   applying patches.
2. Extract: Open this folder (or the .zip if you downloaded one).
3. Merge Folders: Drag and drop the Missions\ and Scripts\ folders into
   your main T34 vs Tiger install directory.
4. Overwrite: When prompted, select "Replace the files in the destination."
5. Clear the cache: Run `TvT cacheDel.bat` (in your main install folder)
   before launching, or the game may keep using old compiled scripts.
6. Launch as normal.

**Notes:**

Full details, including the reasoning behind each fix, are in the
CHANGELOG and TODO on GitHub:
https://github.com/murkzuk/t34-vs-tiger-docs

This hotfix was put together with Claude Code (Anthropic AI coding
assistant) - see the forum post for more on how that's being used
alongside the rest of the REDUX work.
